﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Logear : MonoBehaviour
{
    public void EmpezarInicio()
    {
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void EmpezarRegistro()
    {
        SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void CerrarJuego()
    {
        Application.Quit();
        Debug.Log("Salir");
    }
}
