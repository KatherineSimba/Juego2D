﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Gamekit2D
{
    public class AudioSurface : MonoBehaviour
    {
        public TileBase tile;
    }
}