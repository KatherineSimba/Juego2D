﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Gamekit2D
{
    [CustomEditor(typeof(DirectorTrigger))]
    public class DirectorTriggerEditor : DataPersisterEditor
    {}
}