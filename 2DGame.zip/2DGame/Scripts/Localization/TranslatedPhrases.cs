﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Gamekit2D
{
    [CreateAssetMenu]
    public class TranslatedPhrases : OriginalPhrases
    {
        public OriginalPhrases originalPhrases;
    }
}