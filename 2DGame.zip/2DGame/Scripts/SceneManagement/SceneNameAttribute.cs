﻿using UnityEngine;

namespace Gamekit2D
{
    public class SceneNameAttribute : PropertyAttribute
    {}
}