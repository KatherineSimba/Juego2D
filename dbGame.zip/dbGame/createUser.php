<?php 
include "dbConnection.php";

$userName = $_POST['userName'];
$email = $_POST['email'];
$pass = hash("sha256" , $_POST['pass']);

$sql = "SELECT userName From usuarios Where userName = '$userName'";
$result = $pdo->query($sql);

if($result->rowCount() > 0)
{
    $data = array('done' => false, 'message' => "Error nombre de usuario ya existe");
    Header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}
else
{
    $sql = "SELECT email From usuarios Where email = '$email'";
    $result = $pdo->query($sql);

    if($result->rowCount() > 0)
    {
        $data = array('done' => false, 'message' => "Error email ya existe");
        Header('Content-Type: application/json');
        echo json_encode($data);
        exit();
    }
    else
    {
        $sql = "INSERT INTO usuarios SET userName = '$userName', email = '$email', password = '$pass'";
        $pdo->query($sql);

        $data = array('done' => true, 'message' => "Usuario nuevo creado");
        Header('Content-Type: application/json');
        echo json_encode($data);
        exit();
    }
}

 ?>